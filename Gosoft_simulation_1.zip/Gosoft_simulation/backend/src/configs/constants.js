const DB_HOST = 'localhost'
const DB_USER = 'root'
const DB_PASSWORD = '1234'
const DB_DATABASE = 'stocks_db'
const DB_PORT = 3306

// Server
const PORT = 3000


module.exports = {
  DB_HOST,
  DB_USER,
  DB_PASSWORD,
  DB_DATABASE,
  DB_PORT,
  PORT
}